﻿namespace Ice_Cream_parler
{
    partial class FamilyPack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel6 = new Panel();
            label11 = new Label();
            pictureBox4 = new PictureBox();
            panel5 = new Panel();
            label8 = new Label();
            pictureBox3 = new PictureBox();
            panel7 = new Panel();
            label10 = new Label();
            pictureBox5 = new PictureBox();
            panel8 = new Panel();
            label9 = new Label();
            pictureBox6 = new PictureBox();
            panel4 = new Panel();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            panel3 = new Panel();
            label6 = new Label();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            pictureBox7 = new PictureBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            lable1 = new Label();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel6
            // 
            panel6.BackColor = Color.Orchid;
            panel6.Controls.Add(label11);
            panel6.Controls.Add(pictureBox4);
            panel6.Location = new Point(832, 398);
            panel6.Name = "panel6";
            panel6.Size = new Size(202, 215);
            panel6.TabIndex = 41;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = SystemColors.ButtonHighlight;
            label11.Location = new Point(36, 175);
            label11.Name = "label11";
            label11.Size = new Size(140, 28);
            label11.TabIndex = 5;
            label11.Text = "Black Currant";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.f7;
            pictureBox4.Location = new Point(19, 17);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(161, 145);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 0;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Orchid;
            panel5.Controls.Add(label8);
            panel5.Controls.Add(pictureBox3);
            panel5.Location = new Point(832, 141);
            panel5.Name = "panel5";
            panel5.Size = new Size(202, 215);
            panel5.TabIndex = 37;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ButtonHighlight;
            label8.Location = new Point(36, 176);
            label8.Name = "label8";
            label8.Size = new Size(131, 28);
            label8.TabIndex = 2;
            label8.Text = "Fruit Bonaza";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.f3;
            pictureBox3.Location = new Point(19, 17);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(161, 145);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Orchid;
            panel7.Controls.Add(label10);
            panel7.Controls.Add(pictureBox5);
            panel7.Location = new Point(569, 398);
            panel7.Name = "panel7";
            panel7.Size = new Size(202, 215);
            panel7.TabIndex = 40;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = SystemColors.ButtonHighlight;
            label10.Location = new Point(40, 175);
            label10.Name = "label10";
            label10.Size = new Size(120, 28);
            label10.TabIndex = 4;
            label10.Text = "Staawberry";
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.f9;
            pictureBox5.Location = new Point(19, 17);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(161, 145);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 0;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Orchid;
            panel8.Controls.Add(label9);
            panel8.Controls.Add(pictureBox6);
            panel8.Location = new Point(309, 398);
            panel8.Name = "panel8";
            panel8.Size = new Size(202, 215);
            panel8.TabIndex = 39;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = SystemColors.ButtonHighlight;
            label9.Location = new Point(39, 175);
            label9.Name = "label9";
            label9.Size = new Size(116, 28);
            label9.TabIndex = 3;
            label9.Text = "Kasar Pista";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.f6;
            pictureBox6.Location = new Point(19, 17);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(161, 145);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 0;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Orchid;
            panel4.Controls.Add(label7);
            panel4.Controls.Add(pictureBox2);
            panel4.Location = new Point(569, 141);
            panel4.Name = "panel4";
            panel4.Size = new Size(202, 215);
            panel4.TabIndex = 38;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ButtonHighlight;
            label7.Location = new Point(19, 178);
            label7.Name = "label7";
            label7.Size = new Size(154, 28);
            label7.TabIndex = 1;
            label7.Text = "Choco Brownie";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.f1;
            pictureBox2.Location = new Point(19, 17);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(161, 145);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Orchid;
            panel3.Controls.Add(label6);
            panel3.Controls.Add(pictureBox1);
            panel3.Location = new Point(309, 141);
            panel3.Name = "panel3";
            panel3.Size = new Size(213, 215);
            panel3.TabIndex = 36;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(3, 176);
            label6.Name = "label6";
            label6.Size = new Size(210, 28);
            label6.TabIndex = 2;
            label6.Text = "CrunchyButterscotch";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.f2;
            pictureBox1.Location = new Point(19, 17);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(161, 145);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Purple;
            panel2.Controls.Add(pictureBox7);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(12, 125);
            panel2.Name = "panel2";
            panel2.Size = new Size(250, 506);
            panel2.TabIndex = 35;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.arrow;
            pictureBox7.Location = new Point(3, 3);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(34, 35);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 5;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(75, 142);
            label5.Name = "label5";
            label5.Size = new Size(98, 46);
            label5.TabIndex = 4;
            label5.Text = "Cups";
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(21, 342);
            label4.Name = "label4";
            label4.Size = new Size(206, 46);
            label4.TabIndex = 3;
            label4.Text = "Family Pack";
            label4.Click += label4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(50, 278);
            label3.Name = "label3";
            label3.Size = new Size(144, 46);
            label3.TabIndex = 2;
            label3.Text = "Candies";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(66, 210);
            label2.Name = "label2";
            label2.Size = new Size(116, 46);
            label2.TabIndex = 1;
            label2.Text = "Cones";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(66, 69);
            label1.Name = "label1";
            label1.Size = new Size(116, 46);
            label1.TabIndex = 0;
            label1.Text = "Home";
            label1.Click += label1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Purple;
            panel1.Controls.Add(lable1);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(1058, 98);
            panel1.TabIndex = 34;
            // 
            // lable1
            // 
            lable1.AutoSize = true;
            lable1.Font = new Font("Showcard Gothic", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lable1.ForeColor = SystemColors.ButtonHighlight;
            lable1.Location = new Point(250, 9);
            lable1.Name = "lable1";
            lable1.Size = new Size(580, 74);
            lable1.TabIndex = 0;
            lable1.Text = "Ice-Cream parler";
            // 
            // FamilyPack
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Plum;
            ClientSize = new Size(1082, 643);
            Controls.Add(panel6);
            Controls.Add(panel5);
            Controls.Add(panel7);
            Controls.Add(panel8);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "FamilyPack";
            Text = "FamilyPack";
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel6;
        private Label label11;
        private PictureBox pictureBox4;
        private Panel panel5;
        private Label label8;
        private PictureBox pictureBox3;
        private Panel panel7;
        private Label label10;
        private PictureBox pictureBox5;
        private Panel panel8;
        private Label label9;
        private PictureBox pictureBox6;
        private Panel panel4;
        private Label label7;
        private PictureBox pictureBox2;
        private Panel panel3;
        private Label label6;
        private PictureBox pictureBox1;
        private Panel panel2;
        private PictureBox pictureBox7;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Panel panel1;
        private Label lable1;
    }
}